"""
XML Validation Test Suite for Assignment 1
Assignment: Change Text Content in activity_main.xml
Validates that student XML correctly changes text from "Hello World!" to "Hi Android"
"""

import pytest
from lxml import etree
from pathlib import Path


class TestXMLValidation:
    """Validates Assignment 1 - Change Text Content"""

    @pytest.fixture
    def xml_file(self):
        """Get path to student's XML file"""
        xml_path = Path("/submission/activity_main.xml")
        if not xml_path.exists():
            pytest.skip("activity_main.xml not found in submission folder")
        return xml_path

    @pytest.fixture
    def xml_root(self, xml_file):
        """Parse and return XML root element"""
        try:
            tree = etree.parse(str(xml_file))
            return tree.getroot()
        except etree.XMLSyntaxError as e:
            pytest.fail(f"XML parsing failed: {e}")

    def test_001_xml_is_valid(self, xml_root):
        """Test 1: XML is well-formed and parses successfully"""
        assert xml_root is not None, "XML root element should exist"

    def test_002_root_is_constraint_layout(self, xml_root):
        """Test 2: Root element is ConstraintLayout"""
        tag_name = xml_root.tag
        assert "ConstraintLayout" in tag_name, f"Expected ConstraintLayout root, got {tag_name}"

    def test_003_has_namespaces(self, xml_root):
        """Test 3: All required namespaces are declared"""
        nsmap = xml_root.nsmap
        assert "android" in nsmap, "Missing android namespace"
        assert "app" in nsmap, "Missing app namespace"
        assert "tools" in nsmap, "Missing tools namespace"

    def test_004_textview_element_exists(self, xml_root):
        """Test 4: TextView element exists in layout"""
        # Define namespaces
        ns = {
            'android': 'http://schemas.android.com/apk/res/android',
            'app': 'http://schemas.android.com/apk/res-auto'
        }
        
        # Find TextView using namespace-aware search
        textviews = xml_root.findall('.//android:TextView', ns)
        assert len(textviews) > 0, "No TextView element found in layout"

    def test_005_textview_has_text_attribute(self, xml_root):
        """Test 5: TextView has android:text attribute"""
        ns = {'android': 'http://schemas.android.com/apk/res/android'}
        textview = xml_root.find('.//android:TextView', ns)
        
        text_attr = textview.get('{http://schemas.android.com/apk/res/android}text')
        assert text_attr is not None, "TextView missing android:text attribute"

    def test_006_text_is_not_hello_world(self, xml_root):
        """Test 6: Text is NOT "Hello World!" (student modified it)"""
        ns = {'android': 'http://schemas.android.com/apk/res/android'}
        textview = xml_root.find('.//android:TextView', ns)
        
        text_attr = textview.get('{http://schemas.android.com/apk/res/android}text')
        assert text_attr != "Hello World!", "Text must be changed from 'Hello World!'"

    def test_007_text_is_hi_android(self, xml_root):
        """Test 7: Text value equals "Hi Android""""
        ns = {'android': 'http://schemas.android.com/apk/res/android'}
        textview = xml_root.find('.//android:TextView', ns)
        
        text_attr = textview.get('{http://schemas.android.com/apk/res/android}text')
        assert text_attr == "Hi Android", f"Expected 'Hi Android', got '{text_attr}'"

    def test_008_constraints_preserved(self, xml_root):
        """Test 8: All ConstraintLayout constraints are preserved"""
        ns = {
            'android': 'http://schemas.android.com/apk/res/android',
            'app': 'http://schemas.android.com/apk/res-auto'
        }
        textview = xml_root.find('.//android:TextView', ns)
        
        # Check all required constraints exist
        constraints = {
            'layout_constraintTop_toTopOf': '{http://schemas.android.com/apk/res-auto}layout_constraintTop_toTopOf',
            'layout_constraintBottom_toBottomOf': '{http://schemas.android.com/apk/res-auto}layout_constraintBottom_toBottomOf',
            'layout_constraintStart_toStartOf': '{http://schemas.android.com/apk/res-auto}layout_constraintStart_toStartOf',
            'layout_constraintEnd_toEndOf': '{http://schemas.android.com/apk/res-auto}layout_constraintEnd_toEndOf',
        }
        
        for constraint_name, constraint_ns_tag in constraints.items():
            constraint_value = textview.get(constraint_ns_tag)
            assert constraint_value == "parent", f"Constraint {constraint_name} missing or incorrect"


class TestXMLAttributePresence:
    """Additional validation for XML structure"""

    @pytest.fixture
    def xml_root(self):
        """Parse and return XML root element"""
        xml_path = Path("/submission/activity_main.xml")
        tree = etree.parse(str(xml_path))
        return tree.getroot()

    def test_009_textview_layout_width_exists(self, xml_root):
        """Test 9: TextView has layout_width attribute"""
        ns = {'android': 'http://schemas.android.com/apk/res/android'}
        textview = xml_root.find('.//android:TextView', ns)
        
        width = textview.get('{http://schemas.android.com/apk/res/android}layout_width')
        assert width is not None, "TextView missing android:layout_width"

    def test_010_textview_layout_height_exists(self, xml_root):
        """Test 10: TextView has layout_height attribute"""
        ns = {'android': 'http://schemas.android.com/apk/res/android'}
        textview = xml_root.find('.//android:TextView', ns)
        
        height = textview.get('{http://schemas.android.com/apk/res/android}layout_height')
        assert height is not None, "TextView missing android:layout_height"


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
